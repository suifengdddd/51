#ifndef  DELAY_H
#define  DELAY_H
#include "STC51.h"
void delay1ms(void);
void delayms(uint16 number);
void delay(uint16 number);
#endif
